<?php
//-- Authorization check
require_once 'vendor/login.php';
//-- Connect to the database
require_once 'config/connect.php';


//-- Form the page number
if (isset($_GET['page_num'])) {
    $page_num = $_GET['page_num'];
} else {
    $page_num = 1;
}

//-- Set the size of users on the page
$page_len = 9;
//-- Calculate the number of pages
$users_count = $connect->query("SELECT COUNT(*) FROM `users`")
    ->fetch_array();
$pages_count = ceil($users_count[0] / $page_len);

//-- Correcting possible overstepping
if ($page_num < 1) {
    $page_num = 1;
}
if ($page_num > $pages_count) {
    $page_num = $pages_count;
}

//-- Fetching all the page records
$offset = ($page_num - 1) * $page_len;
$users = $connect->query("SELECT * FROM `users` ORDER BY `id` DESC LIMIT $page_len OFFSET $offset");
$users = $users->fetch_all();
$connect->close();
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Users</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
          integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
            crossorigin="anonymous"></script>
</head>
<body class="container">
<!--    Logout-->
<a class="btn btn-danger my-5" href="/vendor/logout.php">Logout</a>

<!--    Create new user-->
<a class="btn btn-info my-5" href="create.php">Create new user</a>

<!--    Display all users-->
<h3>All Users</h3>
<table class="table table-striped table-hover table_sort">
    <thead>
    <tr>
        <th class="dropdown-toggle" role="button">ID</th>
        <th class="dropdown-toggle" role="button">First Name</th>
        <th class="dropdown-toggle" role="button">Last Name</th>
        <th class="dropdown-toggle" role="button">Gender</th>
        <th class="dropdown-toggle" role="button">Birth Day</th>
        <th class="text-end">Actions</th>
    </tr>
    </thead>
    <tbody>
    <?php foreach ($users as $user) { ?>
        <tr>
            <th><?= $user[0] ?></th>
            <td><?= $user[3] ?></td>
            <td><?= $user[4] ?></td>
            <td><?= $user[5] == 'm' ? 'Male' : 'Female' ?></td>
            <td><?= $user[6] ?></td>
            <td class="text-end">
                <div class="btn-group" role="group">
                    <!--                        Show a detailed page about the user-->
                    <a class="btn btn-sm btn-outline-info" href="show.php?id=<?= $user[0] ?>">Show</a>
                    <!--                        Update a specific user-->
                    <a class="btn btn-sm btn-outline-success" href="edit.php?id=<?= $user[0] ?>">Edit</a>
                    <!--                        Delete a specific user-->
                    <a class="btn btn-sm btn-outline-danger" href="/vendor/delete.php?id=<?= $user[0] ?>">Delete</a>
                </div>
            </td>
        </tr>
    <?php }

    ?>
    </tbody>
</table>
<!--    Adding pagination buttons-->
<?php include 'vendor/pagination.php'; ?>
</body>
<script src="js/table_sort.js"></script>
</html>