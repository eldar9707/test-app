<?php
//-- Connect to database
$host = '';
$username = '';
$password = '';
$db_name = '';

$connect = new mysqli($host, $username, $password, $db_name);
if ($connect->connect_errno) {
    exit('Error connecting to database');
}