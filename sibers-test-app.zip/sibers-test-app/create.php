<?php
require_once 'vendor/login.php';
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
          integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
            crossorigin="anonymous"></script>

    <title>Create User</title>
</head>
<body class="container">
<h3 class="my-5">Add new user</h3>
<div class="col-4">
    <form action="/vendor/create_or_update.php" method="POST">
        <div class="mb-3">
            <label class="form-label" for="login">Login</label>
            <input class="form-control" id="login" type="text" name="login" placeholder="Enter login">
        </div>
        <div class="mb-3">
            <label class="form-label" for="password">Password</label>
            <input class="form-control" id="password" type="password" name="password" placeholder="Enter password">
        </div>
        <div class="mb-3">
            <label class="form-label" for="first_name">First name</label>
            <input class="form-control" type="text" id="first_name" name="first_name" placeholder="Enter first name">
        </div>
        <div class="mb-3">
            <label class="form-label" for="last_name">Last name</label>
            <input class="form-control" type="text" id="last_name" name="last_name" placeholder="Enter last name">
        </div>
        <div class="mb-3">
            <label class="form-label" for="gender">Choose gender</label>
            <select class="form-select" name="gender" id="gender">
                <option value="m">Male</option>
                <option value="f">Female</option>
            </select>
        </div>
        <div class="mb-3">
            <label class="form-label" for="bDay">Choose date of birth</label>
            <input class="form-control" type="date" id="bDay" name="bDay">
        </div>

        <button class="btn btn-success" type="submit">Create</button>
        <a class="btn btn-info" href="index.php">All users</a>
    </form>
</div>
</body>
</html>