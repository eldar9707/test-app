<?php
//-- Authorization check
require_once 'vendor/login.php';
//-- Connect to the database
require_once 'config/connect.php';


//-- Check if such user exists
$user_id = $_GET['id'];
$user = $connect->query("SELECT * FROM `users` WHERE `id`='$user_id'")
    ->fetch_assoc();
$connect->close();
if (!isset($user)) {
    exit('User not found');
}
?>


<!doctype html>
<html lang="en">
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
          integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
            crossorigin="anonymous"></script>
    <meta charset="UTF-8">
    <title>Edit</title>
</head>
<body class="container">
<!-- Displaying edit form-->
<h3 class="my-5">Edit user</h3>
<div class="col-4">
    <form action="/vendor/create_or_update.php" method="POST">
        <input type="hidden" name="id" value="<?= $user['id'] ?>">
        <div class="mb-3">
            <label class="form-label" for="login">Login</label>
            <input class="form-control" id="login" type="text" name="login" placeholder="Enter login"
                   value="<?= $user['login'] ?>">
        </div>
        <div class="mb-3">
            <label class="form-label" for="password">Password</label>
            <input class="form-control" id="password" type="password" name="password" placeholder="Enter password"
                   value="<?= $user['password'] ?>">
        </div>
        <div class="mb-3">
            <label class="form-label" for="first_name">First name</label>
            <input class="form-control" type="text" id="first_name" name="first_name" placeholder="Enter first name"
                   value="<?= $user['first_name'] ?>">
        </div>
        <div class="mb-3">
            <label class="form-label" for="last_name">Last name</label>
            <input class="form-control" type="text" id="last_name" name="last_name" placeholder="Enter last name"
                   value="<?= $user['last_name'] ?>">
        </div>
        <div class="mb-3">
            <label class="form-label" for="gender">Choose gender</label>
            <select class="form-select" name="gender" id="gender">
                <option value="m" <?= $user['gender'] == 'm' ? 'selected' : '' ?> >Male</option>
                <option value="f" <?= $user['gender'] == 'f' ? 'selected' : '' ?> >Female</option>
            </select>
        </div>
        <div class="mb-3">
            <label class="form-label" for="bDay">Choose date of birth</label>
            <input class="form-control" type="date" id="bDay" name="bDay" value="<?= $user['bDay'] ?>">
        </div>

        <button class="btn btn-success" type="submit">Update</button>
        <a class="btn btn-info" href="index.php">All users</a>
    </form>
</div>
</body>