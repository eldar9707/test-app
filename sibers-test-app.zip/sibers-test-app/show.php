<?php
//-- Authorization check
require_once 'vendor/login.php';
//-- Connect to the database
require_once 'config/connect.php';


//-- Check if such user exists
$user_id = $_GET['id'];
$user = $connect->query("SELECT * FROM `users` WHERE `id`='$user_id'")
    ->fetch_assoc();
$connect->close();
if (!isset($user)) {
    exit('User not found');
}
?>

<!doctype html>
<html lang="en">
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
          integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
            crossorigin="anonymous"></script>
    <meta charset="UTF-8">
    <title>User</title>
</head>
<body class="container">
<!-- Displaying user information-->
<div class="card mt-5">
    <div class="card-body">
        <h4 class="card-title"><?= $user['first_name'] . ' ' . $user['last_name'] ?></h4>
        <p class="card-text">
            <strong>Login: </strong>
            <?= $user['login'] ?>
        </p>
        <p class="card-text">
            <strong>Gender: </strong>
            <?= $user['gender'] == 'm' ? 'Male' : 'Female' ?>
        </p>
        <p class="card-text">
            <strong>Date of Birth: </strong>
            <?= $user['bDay'] ?>
        </p>
        <a href="index.php" class="btn btn-primary">All Users</a>
    </div>
</div>
</body>
</html>