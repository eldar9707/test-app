Используемый стек: Nginx, Mysql, PHP 7.4, 

Для запуска приложения можете воспользоваться [данным мануалом](https://www.digitalocean.com/community/tutorials/how-to-install-linux-nginx-mysql-php-lemp-stack-on-ubuntu-20-04-ru)

Настройки базы данных прописываются в файле `sibers-test-app/config/connect.php`