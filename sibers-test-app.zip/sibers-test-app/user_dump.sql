-- MySQL dump 10.13  Distrib 8.0.26, for Linux (x86_64)
--
-- Host: localhost    Database: user
-- ------------------------------------------------------
-- Server version	8.0.26-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `login` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `gender` varchar(50) DEFAULT NULL,
  `bDay` date DEFAULT NULL,
  `is_admin` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_id_uindex` (`id`),
  UNIQUE KEY `users_login_uindex` (`login`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (5,'eldar1997','5f4dcc3b5aa765d61d8327deb882cf99','Eldar','Djakypov','m','1997-12-05',1),(6,'penselok','5f4dcc3b5aa765d61d8327deb882cf99','Kevin','Smith','m','1995-12-09',0),(13,'Nyam7654','5f4dcc3b5aa765d61d8327deb882cf99','John','Doe','m','1995-11-09',0),(14,'ololo','5f4dcc3b5aa765d61d8327deb882cf99','Meri','Smith','f','1992-11-09',0),(15,'myrza','5f4dcc3b5aa765d61d8327deb882cf99','Myrzabek','Kubanych','m','1998-11-10',0),(16,'aiba_gangsta','5f4dcc3b5aa765d61d8327deb882cf99','Aiba','Smith','m','1994-11-09',0),(17,'logotipe','5f4dcc3b5aa765d61d8327deb882cf99','John','Doe','m','1999-11-11',0),(18,'samson','3d8022861f6e74908c249306d39b6a93','Samson','Toporov','m','1979-01-18',0),(21,'userbook','5deb466b0e4c0c313bc6ac950d4247c4','Albert','Solvette','m','1974-04-22',0),(22,'login','df3939f11965e7e75dbc046cd9af1c67','Clark','Doe','m','1987-11-08',0),(24,'qweshka','45eacc2ad6e3592fb110711d0a4fd194','Masha','Poper','f','1987-11-18',0),(26,'newlogin','7741b704aa0ab9a0fd37caeb8dc7b3c7','Elena','Popova','f','1999-07-07',0),(28,'Larisa222','6b475ea8fdcf667b5c183b9ef98f020f','Larisa','Larisovna','f','1990-11-25',0),(30,'Petya776','6b475ea8fdcf667b5c183b9ef98f020f','Petya','Petrov','m','1992-11-17',0),(31,'admin','5f4dcc3b5aa765d61d8327deb882cf99','Admin','Adminov','m','1997-12-05',1),(33,'aircraft2','020adb3f479eeec708d5e1c89a8b33af','Jack','Ivanov','m','1996-04-02',0),(34,'koshechka','8fb8b4736f9f74bb1d301491e1798b08','Katya','Nesterova','m','2001-01-01',0),(35,'sema777','7e15a9c7940b050723506e1bdc6c4fc3','Sema','Malinovich','m','1998-03-05',0),(36,'daria','652a87b1db4e2cc29ceee0b28be21769','Dashka','Svegg','f','1958-06-05',0);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-11-05 14:55:22
